//
//  Tutor.swift
//  tutorFinder
//
//  Created by D.O. on 4/5/16.
//  Copyright © 2016 ZhangYipeng. All rights reserved.
//

import UIKit


class Tutor: UITableViewCell {

}
