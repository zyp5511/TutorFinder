//
//  filterCell.swift
//  tutorFinder
//
//  Created by D.O. on 4/5/16.
//  Copyright © 2016 ZhangYipeng. All rights reserved.
//

import UIKit

class filterCell: UITableViewCell {
    @IBOutlet weak var label1: UILabel!
    
    @IBOutlet weak var label2: UILabel!
    
}
