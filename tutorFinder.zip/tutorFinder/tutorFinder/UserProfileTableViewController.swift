//
//  UserProfileTableViewController.swift
//  tutorFinder
//
//  Created by Zihan Zhang on 4/28/16.
//  Copyright © 2016 ZhangYipeng. All rights reserved.
//

import UIKit

class UserProfileTableViewController: UITableViewController {
    var email = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(email)
        
    }


}
